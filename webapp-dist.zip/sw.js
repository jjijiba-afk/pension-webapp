/* 오프라인 캐시.
 *
 * 처음 접속할 때 앱 파일 전부(런타임 포함)를 캐시해 두면, 이후에는 네트워크
 * 없이 돈다. 캐시 이름에 빌드 해시가 들어 있어 앱을 고치면 이전 캐시는
 * 통째로 버려진다 — 반쯤 섞인 버전이 돌아다니는 것이 최악이다.
 */
"use strict";
const CACHE = "pension-42e5aced24bf";
const PRECACHE = ["./app.css", "./app.js", "./icon-180.png", "./icon-512.png", "./index.html", "./manifest.webmanifest", "./pyodide/pyodide-lock.json", "./pyodide/pyodide.asm.js", "./pyodide/pyodide.asm.wasm", "./pyodide/pyodide.js", "./pyodide/python_stdlib.zip", "./wheels/et_xmlfile-2.0.0-py3-none-any.whl", "./wheels/openpyxl-3.1.5-py2.py3-none-any.whl", "./wheels/pension_actuarial-1.0.0-py3-none-any.whl", "./wheels/xlrd-2.0.2-py2.py3-none-any.whl"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(
        names.filter((name) => name !== CACHE).map((name) => caches.delete(name))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request, { ignoreSearch: true })
      .then((hit) => hit || fetch(event.request))
  );
});
